<?php

define ("DB_HOST", "127.0.0.1");
// Enbart för att min installation av Apache inte kan lyssna på port 80.
define ("DB_PORT", "3306");
define ("DB_NAME", "MDS");
define ("DB_USER", "root");
define ("DB_PASS", "");