<?php

/*
ID : AI INT
timeStamp : DATETIME
Message : STRING
priority : INT

*/

include_once('db.php');

$msg = new pushMessage();

if($msg) {
	echo "Response:";
	if($msg->errors) {
		foreach ($msg->errors as $error) {
			echo $error . "<br />";
		}	
	}
	if($msg->messages) {
		foreach($msg->messages as $mesg) {
			echo $mesg . "<br />";
		}
	}
} else {
	echo "Couldn't create class";
}


class pushMessage {

	private $db = null;

	public $errors = array();

	public $messages = array();

	private $timeStmp = null;
	private $prio = 0;
	public function __construct() {
		if(isset($_POST["regMsg"])) {
			$this->regMsg();
		}
	}

	private function regMsg() {
		if (empty($_POST['clientID'])) {
			$this->errors[] = "Klient-ID får ej vara tomt.";
		} elseif (empty($_POST['clientKey'])) {
			$this->errors[] = "Klient-Nyckel får ej vara tomt.";
		} elseif (empty($_POST['message'])) {
			$this->errors[] = "Meddelandet får ej vara tomt.";
		} elseif (strlen($_POST['message']) < 16) {
			$this->errors[] = "Meddelandet måste vara minst 16 tecken långt.";
		} elseif (strlen($_POST['message']) > 1000) {
			$this->errors[] = "Meddelandet får ej vara längre än 1000 tecken.";
		} elseif (!empty($_POST['clientID']) 
				&& !empty($_POST['clientKey'])
				&& !empty($_POST['message'])
				&& strlen($_POST['message']) >= 16
				&& strlen($_POST['message']) <= 1000) {
			$this->db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
			$this->db->query("SET CHARACTER SET utf8");

			if(!$this->db->connect_errno) {
				$prio = $_POST['prio'];
				if(!empty($_POST['time'])) {
					$timeStmp = $_POST['time'];
				} else {
					$timeStmp = "NOW()";
				}
				$message = $_POST['message'];

				$sql = "INSERT INTO messages (dateStamp, message, priority) ".
						"VALUES ('".$timeStmp."', '".$message."', '".
							$prio."');";
				$query = $this->db->query($sql);
				if($query) {
					$this->messages[] = "Meddelandet är nu upplagt.";
				} else {
					$this->errors[] = "Det gick inte att skapa meddelandet. <br/>" . $this->db->error;
				}
			} else {
				$this->errors[] = "Oj då, verkar som att en smurf har fipplat med databasen.";
			}
		} else {
			$this->errors[] = "Det verkar som att all information inte kom fram, eller så stämmer inte formatering på något fält.";
		}
	}
}
?>