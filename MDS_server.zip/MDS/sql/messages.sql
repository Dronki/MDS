-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Värd: 127.0.0.1
-- Tid vid skapande: 03 dec 2015 kl 21:47
-- Serverversion: 5.6.25
-- PHP-version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databas: `mds`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `ID` int(255) NOT NULL,
  `dateStamp` datetime NOT NULL,
  `message` text NOT NULL,
  `priority` int(1) NOT NULL DEFAULT '0' COMMENT '1, 2, 3 = priosteg, 0 = ingen prio.'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `messages`
--

INSERT INTO `messages` (`ID`, `dateStamp`, `message`, `priority`) VALUES
(1, '2015-11-27 10:51:04', 'Detta är ett test-meddelande.\r\nDock så är detta publicerat från PHPMYADMIN-panelen.', 3),
(2, '2015-12-03 00:00:00', 'asdasdhasjkdhjkaslhdjklashdjskal', 2),
(3, '2015-12-03 00:00:00', 'adjahjdksahjkdhsjkahdjkashdjksahl', 0),
(4, '2015-12-24 00:00:00', ' ahjksdhasjkhdjklashdjklahjdkhasjkdhasjkl hsa', 3);

--
-- Index för dumpade tabeller
--

--
-- Index för tabell `messages`
--
ALTER TABLE `messages`
  ADD UNIQUE KEY `ID` (`ID`),
  ADD KEY `key` (`ID`);

--
-- AUTO_INCREMENT för dumpade tabeller
--

--
-- AUTO_INCREMENT för tabell `messages`
--
ALTER TABLE `messages`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
