-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Värd: 127.0.0.1
-- Tid vid skapande: 27 nov 2015 kl 10:36
-- Serverversion: 5.6.25
-- PHP-version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databas: `MDS`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `ID` int(255) NOT NULL,
  `clientID` int(64) NOT NULL,
  `clientKey` int(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellstruktur `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `ID` int(255) NOT NULL,
  `dateStamp` datetime NOT NULL,
  `message` text NOT NULL,
  `priority` int(1) NOT NULL DEFAULT '0' COMMENT '1, 2, 3 = priosteg, 0 = ingen prio.'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index för dumpade tabeller
--

--
-- Index för tabell `clients`
--
ALTER TABLE `clients`
  ADD KEY `key` (`ID`);

--
-- Index för tabell `messages`
--
ALTER TABLE `messages`
  ADD KEY `key` (`ID`);

--
-- AUTO_INCREMENT för dumpade tabeller
--

--
-- AUTO_INCREMENT för tabell `clients`
--
ALTER TABLE `clients`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT för tabell `messages`
--
ALTER TABLE `messages`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
