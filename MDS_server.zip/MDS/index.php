<?php

include_once('system/db.php');


?>

<table border="1" style="width:100%">
	<tr>
		<th>Datum&nbsp;<a href="?order=DESC&key=dateStamp"><img src="assets/down_arrow.png"/></a>&nbsp;<a href="?order=ASC&key=dateStamp"><img src="assets/up_arrow.png"/></a></th>
		<th>Prioritet&nbsp;<a href="?order=DESC&key=priority"><img src="assets/down_arrow.png"/></a>&nbsp;<a href="?order=ASC&key=priority"><img src="assets/up_arrow.png"/></a></th>
		<th>Meddelande</th>
	</tr>
	<?php $get = new getMessages(); ?>
</table>

<?php


class getMessages {

	private $db = null;

	public $errors = array();

	public $messages = array();

	function __construct() {
		$this->listMessages();
	}


	private function listMessages() {
		$this->db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
		$this->db->query("SET CHARACTER SET utf8");

		$order = "";
		$key = "";

		if(empty($_GET["order"]))
			$order = "DESC";
		else
			$order = $_GET["order"];

		if(empty($_GET["key"]))
			$key = "priority";
		else
			$key = $_GET["key"];

		if(!$this->db->connect_errno) {
			$sql = "SELECT * from messages ORDER BY ". $key ." " . $order;
			if($result = $this->db->query($sql)) {
				
				while($row = $result->fetch_row()) {
					echo "<tr>";
					echo "<td>" . $row[1] ."</td>";
					echo "<td>" . $row[3] ."</td>";
					echo "<td>" . $row[2] ."</td>";
					echo "</tr>";
					//echo "<tr>" . $row[1] . " | " . $row[2] . " | " . $row[3];
				}
				
			}
		}
	}

}

?>